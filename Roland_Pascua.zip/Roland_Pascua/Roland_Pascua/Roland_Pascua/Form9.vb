﻿Public Class Form9
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs)
        TextBox2.Text = Val(TextBox1.Text) * 67.5
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs)
        TextBox2.Text = Val(TextBox1.Text) * 12.13
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs)
        TextBox2.Text = Val(TextBox1.Text) * 8.96
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs)
        TextBox2.Text = Val(TextBox1.Text) * 50.33
    End Sub

    Private Sub RadioButton5_CheckedChanged(sender As Object, e As EventArgs)
        TextBox2.Text = Val(TextBox1.Text) * 2.5
    End Sub
End Class