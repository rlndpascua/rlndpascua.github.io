﻿Public Class Form4
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        txtchange.Text = Val(txtRec.Text) - Val(txtAmount.Text) * (Val(txtDis.Text) / 100)
    End Sub
End Class