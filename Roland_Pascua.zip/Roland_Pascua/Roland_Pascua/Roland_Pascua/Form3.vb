﻿Public Class Form3
    Private Sub chkPinakbet_CheckedChanged(sender As Object, e As EventArgs) Handles chkPinakbet.CheckedChanged
        If chkPinakbet.Checked = True Then
            txtVeg.Text = 45
        Else
            txtVeg.Text = ""
        End If
        If chkPinakbet.Checked = True And chkChopsuey.Checked = True Then
            txtVeg.Text = 95
        ElseIf chkPinakbet.Checked = False And chkChopsuey.Checked = True Then
            txtVeg.Text = 50
        End If
    End Sub

    Private Sub chkChopsuey_CheckedChanged(sender As Object, e As EventArgs) Handles chkChopsuey.CheckedChanged
        If chkChopsuey.Checked = True Then
            txtVeg.Text = 50
        Else
            txtVeg.Text = ""
        End If
        If chkPinakbet.Checked = True And chkChopsuey.Checked = True Then
            txtVeg.Text = 95
        ElseIf chkPinakbet.Checked = True And chkChopsuey.Checked = False Then
            txtVeg.Text = 45
        End If
    End Sub

    Private Sub chkBicol_CheckedChanged(sender As Object, e As EventArgs) Handles chkBicol.CheckedChanged
        If chkBicol.Checked = True Then
            txtPork.Text = 150
        Else
            txtPork.Text = ""
        End If
        If chkBicol.Checked = True And chkLetchon.Checked = True Then
            txtPork.Text = 350
        ElseIf chkBicol.Checked = False And chkLetchon.Checked = True Then
            txtPork.Text = 200
        End If
    End Sub

    Private Sub chkLetchon_CheckedChanged(sender As Object, e As EventArgs) Handles chkLetchon.CheckedChanged
        If chkLetchon.Checked = True Then
            txtPork.Text = 200
        Else
            txtPork.Text = ""
        End If
        If chkBicol.Checked = True And chkLetchon.Checked = True Then
            txtPork.Text = 350
        ElseIf chkBicol.Checked = True And chkLetchon.Checked = False Then
            txtPork.Text = 150
        End If
    End Sub

    Private Sub chkChicken_CheckedChanged(sender As Object, e As EventArgs) Handles chkChicken.CheckedChanged
        If chkChicken.Checked = True Then
            txtChi.Text = 100
        Else
            txtChi.Text = ""
        End If
        If chkChicken.Checked = True And chkSpring.Checked = True Then
            txtChi.Text = 250
        ElseIf chkChicken.Checked = False And chkSpring.Checked = True Then
            txtChi.Text = 150
        End If
    End Sub

    Private Sub chkSpring_CheckedChanged(sender As Object, e As EventArgs) Handles chkSpring.CheckedChanged
        If chkSpring.Checked = True Then
            txtChi.Text = 150
        Else
            txtChi.Text = ""
        End If
        If chkChicken.Checked = True And chkSpring.Checked = True Then
            txtChi.Text = 250
        ElseIf chkChicken.Checked = True And chkSpring.Checked = False Then
            txtChi.Text = 100
        End If
    End Sub

    Private Sub chkBaka_CheckedChanged(sender As Object, e As EventArgs) Handles chkBaka.CheckedChanged
        If chkBaka.Checked = True Then
            txtBeef.Text = 100
        Else
            txtBeef.Text = ""
        End If
        If chkBaka.Checked = True And chkBeef.Checked = True Then
            txtBeef.Text = 350
        ElseIf chkBaka.Checked = False And chkBeef.Checked = True Then
            txtBeef.Text = 200
        End If
    End Sub

    Private Sub chkBeef_CheckedChanged(sender As Object, e As EventArgs) Handles chkBeef.CheckedChanged
        If chkBeef.Checked = True Then
            txtBeef.Text = 100
        Else
            txtBeef.Text = ""
        End If
        If chkBaka.Checked = True And chkBeef.Checked = True Then
            txtBeef.Text = 350
        ElseIf chkBaka.Checked = True And chkBeef.Checked = False Then
            txtBeef.Text = 150
        End If
    End Sub

    Private Sub rbRegular_CheckedChanged(sender As Object, e As EventArgs) Handles rbRegular.CheckedChanged
        txtRice.Text = 50 * Nud1.Value
    End Sub

    Private Sub rbDanggit_CheckedChanged(sender As Object, e As EventArgs) Handles rbDanggit.CheckedChanged
        txtRice.Text = 70 * Nud1.Value
    End Sub

    Private Sub rbAdobo_CheckedChanged(sender As Object, e As EventArgs) Handles rbAdobo.CheckedChanged
        txtRice.Text = 100 * Nud1.Value
    End Sub

    Private Sub Nud1_ValueChanged(sender As Object, e As EventArgs) Handles Nud1.ValueChanged
        If rbRegular.Checked = True Then
            txtRice.Text = 50 * Nud1.Value
        End If
        If rbDanggit.Checked = True Then
            txtRice.Text = 70 * Nud1.Value
        End If
        If rbAdobo.Checked = True Then
            txtRice.Text = 100 * Nud1.Value
        End If
    End Sub

    Private Sub rbPancit_CheckedChanged(sender As Object, e As EventArgs) Handles rbPancit.CheckedChanged
        txtMer.Text = 30 * Nud2.Value
    End Sub

    Private Sub rbArroz_CheckedChanged(sender As Object, e As EventArgs) Handles rbArroz.CheckedChanged
        txtMer.Text = 50 * Nud2.Value
    End Sub

    Private Sub rbSeafood_CheckedChanged(sender As Object, e As EventArgs) Handles rbSeafood.CheckedChanged
        txtSea.Text = 200 * Nud4.Value
    End Sub

    Private Sub Nud2_ValueChanged(sender As Object, e As EventArgs) Handles Nud2.ValueChanged
        If rbPancit.Checked = True Then
            txtMer.Text = 30 * Nud2.Value
        End If
        If rbArroz.Checked = True Then
            txtMer.Text = 50 * Nud2.Value
        End If
        If rbSeafood.Checked = True Then
            txtMer.Text = 80 * Nud2.Value
        End If
    End Sub

    Private Sub rbHalo_CheckedChanged(sender As Object, e As EventArgs) Handles rbHalo.CheckedChanged
        txtDes.Text = 45 * Nud3.Value
    End Sub

    Private Sub rbGiant_CheckedChanged(sender As Object, e As EventArgs) Handles rbGiant.CheckedChanged
        txtDes.Text = 90 * Nud3.Value
    End Sub

    Private Sub rbFrozen_CheckedChanged(sender As Object, e As EventArgs) Handles rbFrozen.CheckedChanged
        txtDes.Text = 120 * Nud3.Value
    End Sub

    Private Sub rbBoneless_CheckedChanged(sender As Object, e As EventArgs) Handles rbBoneless.CheckedChanged
        txtSea.Text = 120 * Nud4.Value
    End Sub

    Private Sub rbSinigang_CheckedChanged(sender As Object, e As EventArgs) Handles rbSinigang.CheckedChanged
        txtSea.Text = 150 * Nud4.Value
    End Sub

    Private Sub rbBangus_CheckedChanged(sender As Object, e As EventArgs) Handles rbBangus.CheckedChanged
        txtSea.Text = 200 * Nud4.Value
    End Sub

    Private Sub Nud4_ValueChanged(sender As Object, e As EventArgs) Handles Nud4.ValueChanged
        If rbBoneless.Checked = True Then
            txtSea.Text = 120 * Nud4.Value
        End If
        If rbSinigang.Checked = True Then
            txtSea.Text = 150 * Nud4.Value
        End If
        If rbBangus.Checked = True Then
            txtSea.Text = 200 * Nud4.Value
        End If
    End Sub

    Private Sub Nud3_ValueChanged(sender As Object, e As EventArgs) Handles Nud3.ValueChanged
        If rbHalo.Checked = True Then
            txtDes.Text = 45 * Nud3.Value
        End If
        If rbGiant.Checked = True Then
            txtDes.Text = 90 * Nud3.Value
        End If
        If rbFrozen.Checked = True Then
            txtDes.Text = 120 * Nud3.Value
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim form As New Form4
        Form4.txtVeg.Text = txtVeg.Text.ToString
        Form4.txtChi.Text = txtChi.Text.ToString
        Form4.txtPork.Text = txtPork.Text.ToString
        Form4.txtBeef.Text = txtBeef.Text.ToString
        Form4.txtRice.Text = txtRice.Text.ToString
        Form4.txtMer.Text = txtMer.Text.ToString
        Form4.txtDes.Text = txtDes.Text.ToString
        Form4.txtSea.Text = txtSea.Text.ToString
        Form4.ShowDialog()
    End Sub
End Class