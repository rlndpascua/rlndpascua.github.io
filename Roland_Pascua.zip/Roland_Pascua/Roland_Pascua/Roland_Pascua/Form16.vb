﻿Public Class Form16
    Private Sub Button1_Click(sender As Object, e As EventArgs)
        If Val(TextBox1.Text) > 20 Or Val(TextBox1.Text) < 100 Then
            TextBox3.Text = 15
            TextBox4.Text = Val(TextBox3.Text) + Val(TextBox1.Text)

        ElseIf Val(TextBox1.Text) > 101 Or Val(TextBox1.Text) < 500 Then
            TextBox3.Text = 18
            TextBox4.Text = Val(TextBox3.Text) + Val(TextBox1.Text)

        ElseIf Val(TextBox1.Text) > 501 Or Val(TextBox1.Text) < 1000 Then
            TextBox3.Text = 35
            TextBox4.Text = Val(TextBox3.Text) + Val(TextBox1.Text)

        ElseIf Val(TextBox1.Text) > 1001 Or Val(TextBox1.Text) < 5000 Then
            TextBox3.Text = 38
            TextBox4.Text = Val(TextBox3.Text) + Val(TextBox1.Text)

        ElseIf Val(TextBox1.Text) > 5001 Or Val(TextBox1.Text) < 10000 Then
            TextBox3.Text = 55
            TextBox4.Text = Val(TextBox3.Text) + Val(TextBox1.Text)
        End If
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        If Val(TextBox1.Text) > 20 Or Val(TextBox1.Text) < 100 Then
            TextBox3.Text = 15
            TextBox4.Text = Val(TextBox3.Text) + Val(TextBox1.Text)

        ElseIf Val(TextBox1.Text) > 101 Or Val(TextBox1.Text) < 500 Then
            TextBox3.Text = 18
            TextBox4.Text = Val(TextBox3.Text) + Val(TextBox1.Text)

        ElseIf Val(TextBox1.Text) > 501 Or Val(TextBox1.Text) < 1000 Then
            TextBox3.Text = 35
            TextBox4.Text = Val(TextBox3.Text) + Val(TextBox1.Text)

        ElseIf Val(TextBox1.Text) > 1001 Or Val(TextBox1.Text) < 5000 Then
            TextBox3.Text = 38
            TextBox4.Text = Val(TextBox3.Text) + Val(TextBox1.Text)

        ElseIf Val(TextBox1.Text) > 5001 Or Val(TextBox1.Text) < 10000 Then
            TextBox3.Text = 55
            TextBox4.Text = Val(TextBox3.Text) + Val(TextBox1.Text)
        End If
    End Sub
End Class