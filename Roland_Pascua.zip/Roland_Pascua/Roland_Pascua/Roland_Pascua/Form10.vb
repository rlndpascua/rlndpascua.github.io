﻿Public Class Form10
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs)
        TextBox2.Text = Val(TextBox1.Text) * 67.45
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs)
        TextBox2.Text = Val(TextBox1.Text) * 13.52
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs)
        TextBox2.Text = Val(TextBox1.Text) * 8.97
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs)
        TextBox2.Text = Val(TextBox1.Text) * 50.96
    End Sub

    Private Sub RadioButton5_CheckedChanged(sender As Object, e As EventArgs)
        TextBox2.Text = Val(TextBox1.Text) * 2.6
    End Sub
End Class