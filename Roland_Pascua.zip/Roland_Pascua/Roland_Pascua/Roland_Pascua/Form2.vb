﻿Public Class Form2
    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox6.Text = Val(TextBox2.Text * 0.1) + Val(TextBox3.Text * 0.15) + Val(TextBox4.Text * 0.25) + Val(TextBox5.Text * 0.5)
        If TextBox6.Text > 75 Then
            TextBox7.Text = "Passed"
        ElseIf TextBox6.Text < 75 Then
            TextBox7.Text = "Failed"
        End If
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged

    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox9.Text = Val(TextBox11.Text * 0.1) + Val(TextBox13.Text * 0.15) + Val(TextBox12.Text * 0.25) + Val(TextBox10.Text * 0.5)
        If TextBox9.Text > 75 Then
            TextBox8.Text = "Passed"
        ElseIf TextBox9.Text < 75 Then
            TextBox8.Text = "Failed"
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox15.Text = Val(TextBox17.Text * 0.1) + Val(TextBox19.Text * 0.15) + Val(TextBox18.Text * 0.25) + Val(TextBox16.Text * 0.5)
        If TextBox15.Text > 75 Then
            TextBox14.Text = "Passed"
        ElseIf TextBox15.Text < 75 Then
            TextBox14.Text = "Failed"
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        TextBox21.Text = Val(TextBox6.Text) + Val(TextBox9.Text) + Val(TextBox15.Text) / 3
        If TextBox21.Text > 75 Then
            TextBox20.Text = "Passed"
        ElseIf TextBox21.Text < 75 Then
            TextBox20.Text = "Failed"
        End If
    End Sub
End Class