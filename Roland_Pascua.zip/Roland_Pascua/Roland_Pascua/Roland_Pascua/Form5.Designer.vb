﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.tpPayroll = New System.Windows.Forms.TabPage()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtdeductions = New System.Windows.Forms.TextBox()
        Me.txtnet = New System.Windows.Forms.TextBox()
        Me.txtgross = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtptax = New System.Windows.Forms.TextBox()
        Me.txtdeduc = New System.Windows.Forms.TextBox()
        Me.txtbenefits = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.chkaitax = New System.Windows.Forms.CheckBox()
        Me.chkawtax = New System.Windows.Forms.CheckBox()
        Me.chkptax = New System.Windows.Forms.CheckBox()
        Me.chkitax = New System.Windows.Forms.CheckBox()
        Me.chkwtax = New System.Windows.Forms.CheckBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtcoop = New System.Windows.Forms.TextBox()
        Me.txtgsis = New System.Windows.Forms.TextBox()
        Me.txtpagibig = New System.Windows.Forms.TextBox()
        Me.txtsss = New System.Windows.Forms.TextBox()
        Me.txtphilhealth = New System.Windows.Forms.TextBox()
        Me.chkcoop = New System.Windows.Forms.CheckBox()
        Me.chkgsis = New System.Windows.Forms.CheckBox()
        Me.chkpagibig = New System.Windows.Forms.CheckBox()
        Me.chksss = New System.Windows.Forms.CheckBox()
        Me.chkphilhealth = New System.Windows.Forms.CheckBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txttotalrate = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chklaw = New System.Windows.Forms.CheckBox()
        Me.chkdoctorate = New System.Windows.Forms.CheckBox()
        Me.chkmasters = New System.Windows.Forms.CheckBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txttardiness = New System.Windows.Forms.TextBox()
        Me.txthrequired = New System.Windows.Forms.TextBox()
        Me.txthpermonth = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.tpRates = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbjoborder = New System.Windows.Forms.RadioButton()
        Me.rbcontractual = New System.Windows.Forms.RadioButton()
        Me.txtmname = New System.Windows.Forms.TextBox()
        Me.txtfname = New System.Windows.Forms.TextBox()
        Me.txtlname = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpPayroll.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.tpRates.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(72, 258)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(127, 25)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "LAST NAME"
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(215, 18)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(152, 117)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'tpPayroll
        '
        Me.tpPayroll.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tpPayroll.Controls.Add(Me.Button7)
        Me.tpPayroll.Controls.Add(Me.Button6)
        Me.tpPayroll.Controls.Add(Me.Button5)
        Me.tpPayroll.Controls.Add(Me.Button4)
        Me.tpPayroll.Controls.Add(Me.GroupBox6)
        Me.tpPayroll.Controls.Add(Me.Label10)
        Me.tpPayroll.Controls.Add(Me.Label9)
        Me.tpPayroll.Controls.Add(Me.Label8)
        Me.tpPayroll.Controls.Add(Me.txtptax)
        Me.tpPayroll.Controls.Add(Me.txtdeduc)
        Me.tpPayroll.Controls.Add(Me.txtbenefits)
        Me.tpPayroll.Controls.Add(Me.GroupBox5)
        Me.tpPayroll.Controls.Add(Me.GroupBox4)
        Me.tpPayroll.Location = New System.Drawing.Point(4, 34)
        Me.tpPayroll.Name = "tpPayroll"
        Me.tpPayroll.Padding = New System.Windows.Forms.Padding(3)
        Me.tpPayroll.Size = New System.Drawing.Size(570, 725)
        Me.tpPayroll.TabIndex = 1
        Me.tpPayroll.Text = "Payroll Proper"
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(29, 672)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(517, 36)
        Me.Button7.TabIndex = 19
        Me.Button7.Text = "EXIT SYSTEM"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(29, 628)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(517, 38)
        Me.Button6.TabIndex = 18
        Me.Button6.Text = "RESET"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(29, 580)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(517, 38)
        Me.Button5.TabIndex = 17
        Me.Button5.Text = "PROCEED TO PAYOUT"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(29, 530)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(517, 41)
        Me.Button4.TabIndex = 16
        Me.Button4.Text = "PROCEEED TO PREVIOUS PAGE"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Label11)
        Me.GroupBox6.Controls.Add(Me.Label12)
        Me.GroupBox6.Controls.Add(Me.Label13)
        Me.GroupBox6.Controls.Add(Me.txtdeductions)
        Me.GroupBox6.Controls.Add(Me.txtnet)
        Me.GroupBox6.Controls.Add(Me.txtgross)
        Me.GroupBox6.Location = New System.Drawing.Point(7, 356)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(547, 145)
        Me.GroupBox6.TabIndex = 15
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "SALARY"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(35, 99)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(97, 25)
        Me.Label11.TabIndex = 17
        Me.Label11.Text = "NET PAY"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(35, 68)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(144, 25)
        Me.Label12.TabIndex = 16
        Me.Label12.Text = "DEDUCTIONS"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(30, 38)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(168, 25)
        Me.Label13.TabIndex = 15
        Me.Label13.Text = "GROSS SALARY"
        '
        'txtdeductions
        '
        Me.txtdeductions.Location = New System.Drawing.Point(269, 65)
        Me.txtdeductions.Name = "txtdeductions"
        Me.txtdeductions.Size = New System.Drawing.Size(234, 30)
        Me.txtdeductions.TabIndex = 14
        '
        'txtnet
        '
        Me.txtnet.Location = New System.Drawing.Point(269, 99)
        Me.txtnet.Name = "txtnet"
        Me.txtnet.Size = New System.Drawing.Size(234, 30)
        Me.txtnet.TabIndex = 13
        '
        'txtgross
        '
        Me.txtgross.Location = New System.Drawing.Point(269, 33)
        Me.txtgross.Name = "txtgross"
        Me.txtgross.Size = New System.Drawing.Size(234, 30)
        Me.txtgross.TabIndex = 12
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(37, 317)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(216, 25)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "TOTAL DEDUCTIONS"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(42, 281)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(149, 25)
        Me.Label9.TabIndex = 13
        Me.Label9.Text = "PAYABLE TAX"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(37, 246)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(205, 25)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "PAYABLE BENEFITS"
        '
        'txtptax
        '
        Me.txtptax.Location = New System.Drawing.Point(292, 278)
        Me.txtptax.Name = "txtptax"
        Me.txtptax.Size = New System.Drawing.Size(234, 30)
        Me.txtptax.TabIndex = 11
        '
        'txtdeduc
        '
        Me.txtdeduc.Location = New System.Drawing.Point(292, 314)
        Me.txtdeduc.Name = "txtdeduc"
        Me.txtdeduc.Size = New System.Drawing.Size(234, 30)
        Me.txtdeduc.TabIndex = 10
        '
        'txtbenefits
        '
        Me.txtbenefits.Location = New System.Drawing.Point(292, 243)
        Me.txtbenefits.Name = "txtbenefits"
        Me.txtbenefits.Size = New System.Drawing.Size(234, 30)
        Me.txtbenefits.TabIndex = 9
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.chkaitax)
        Me.GroupBox5.Controls.Add(Me.chkawtax)
        Me.GroupBox5.Controls.Add(Me.chkptax)
        Me.GroupBox5.Controls.Add(Me.chkitax)
        Me.GroupBox5.Controls.Add(Me.chkwtax)
        Me.GroupBox5.Location = New System.Drawing.Point(301, 20)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(250, 192)
        Me.GroupBox5.TabIndex = 1
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "TAX"
        '
        'chkaitax
        '
        Me.chkaitax.AutoSize = True
        Me.chkaitax.Location = New System.Drawing.Point(11, 144)
        Me.chkaitax.Name = "chkaitax"
        Me.chkaitax.Size = New System.Drawing.Size(214, 29)
        Me.chkaitax.TabIndex = 9
        Me.chkaitax.Text = "ADVNC. INCM. TAX"
        Me.chkaitax.UseVisualStyleBackColor = True
        '
        'chkawtax
        '
        Me.chkawtax.AutoSize = True
        Me.chkawtax.Location = New System.Drawing.Point(11, 112)
        Me.chkawtax.Name = "chkawtax"
        Me.chkawtax.Size = New System.Drawing.Size(198, 29)
        Me.chkawtax.TabIndex = 8
        Me.chkawtax.Text = "ADVNC. W/H TAX"
        Me.chkawtax.UseVisualStyleBackColor = True
        '
        'chkptax
        '
        Me.chkptax.AutoSize = True
        Me.chkptax.Location = New System.Drawing.Point(11, 83)
        Me.chkptax.Name = "chkptax"
        Me.chkptax.Size = New System.Drawing.Size(184, 29)
        Me.chkptax.TabIndex = 7
        Me.chkptax.Text = "PROPERTY TAX"
        Me.chkptax.UseVisualStyleBackColor = True
        '
        'chkitax
        '
        Me.chkitax.AutoSize = True
        Me.chkitax.Location = New System.Drawing.Point(11, 53)
        Me.chkitax.Name = "chkitax"
        Me.chkitax.Size = New System.Drawing.Size(157, 29)
        Me.chkitax.TabIndex = 6
        Me.chkitax.Text = "INCOME TAX"
        Me.chkitax.UseVisualStyleBackColor = True
        '
        'chkwtax
        '
        Me.chkwtax.AutoSize = True
        Me.chkwtax.Location = New System.Drawing.Point(11, 21)
        Me.chkwtax.Name = "chkwtax"
        Me.chkwtax.Size = New System.Drawing.Size(192, 29)
        Me.chkwtax.TabIndex = 5
        Me.chkwtax.Text = "W/HOLDING TAX"
        Me.chkwtax.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtcoop)
        Me.GroupBox4.Controls.Add(Me.txtgsis)
        Me.GroupBox4.Controls.Add(Me.txtpagibig)
        Me.GroupBox4.Controls.Add(Me.txtsss)
        Me.GroupBox4.Controls.Add(Me.txtphilhealth)
        Me.GroupBox4.Controls.Add(Me.chkcoop)
        Me.GroupBox4.Controls.Add(Me.chkgsis)
        Me.GroupBox4.Controls.Add(Me.chkpagibig)
        Me.GroupBox4.Controls.Add(Me.chksss)
        Me.GroupBox4.Controls.Add(Me.chkphilhealth)
        Me.GroupBox4.Location = New System.Drawing.Point(11, 24)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(272, 192)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "BENEFITS"
        '
        'txtcoop
        '
        Me.txtcoop.Location = New System.Drawing.Point(155, 147)
        Me.txtcoop.Name = "txtcoop"
        Me.txtcoop.Size = New System.Drawing.Size(111, 30)
        Me.txtcoop.TabIndex = 8
        '
        'txtgsis
        '
        Me.txtgsis.Location = New System.Drawing.Point(155, 116)
        Me.txtgsis.Name = "txtgsis"
        Me.txtgsis.Size = New System.Drawing.Size(111, 30)
        Me.txtgsis.TabIndex = 7
        '
        'txtpagibig
        '
        Me.txtpagibig.Location = New System.Drawing.Point(155, 84)
        Me.txtpagibig.Name = "txtpagibig"
        Me.txtpagibig.Size = New System.Drawing.Size(111, 30)
        Me.txtpagibig.TabIndex = 6
        '
        'txtsss
        '
        Me.txtsss.Location = New System.Drawing.Point(155, 52)
        Me.txtsss.Name = "txtsss"
        Me.txtsss.Size = New System.Drawing.Size(111, 30)
        Me.txtsss.TabIndex = 5
        '
        'txtphilhealth
        '
        Me.txtphilhealth.Location = New System.Drawing.Point(155, 19)
        Me.txtphilhealth.Name = "txtphilhealth"
        Me.txtphilhealth.Size = New System.Drawing.Size(111, 30)
        Me.txtphilhealth.TabIndex = 2
        '
        'chkcoop
        '
        Me.chkcoop.AutoSize = True
        Me.chkcoop.Location = New System.Drawing.Point(6, 146)
        Me.chkcoop.Name = "chkcoop"
        Me.chkcoop.Size = New System.Drawing.Size(91, 29)
        Me.chkcoop.TabIndex = 4
        Me.chkcoop.Text = "COOP"
        Me.chkcoop.UseVisualStyleBackColor = True
        '
        'chkgsis
        '
        Me.chkgsis.AutoSize = True
        Me.chkgsis.Location = New System.Drawing.Point(6, 117)
        Me.chkgsis.Name = "chkgsis"
        Me.chkgsis.Size = New System.Drawing.Size(79, 29)
        Me.chkgsis.TabIndex = 3
        Me.chkgsis.Text = "GSIS"
        Me.chkgsis.UseVisualStyleBackColor = True
        '
        'chkpagibig
        '
        Me.chkpagibig.AutoSize = True
        Me.chkpagibig.Location = New System.Drawing.Point(6, 85)
        Me.chkpagibig.Name = "chkpagibig"
        Me.chkpagibig.Size = New System.Drawing.Size(111, 29)
        Me.chkpagibig.TabIndex = 2
        Me.chkpagibig.Text = "PAGIBIG"
        Me.chkpagibig.UseVisualStyleBackColor = True
        '
        'chksss
        '
        Me.chksss.AutoSize = True
        Me.chksss.Location = New System.Drawing.Point(6, 54)
        Me.chksss.Name = "chksss"
        Me.chksss.Size = New System.Drawing.Size(73, 29)
        Me.chksss.TabIndex = 1
        Me.chksss.Text = "SSS"
        Me.chksss.UseVisualStyleBackColor = True
        '
        'chkphilhealth
        '
        Me.chkphilhealth.AutoSize = True
        Me.chkphilhealth.Location = New System.Drawing.Point(6, 23)
        Me.chkphilhealth.Name = "chkphilhealth"
        Me.chkphilhealth.Size = New System.Drawing.Size(153, 29)
        Me.chkphilhealth.TabIndex = 0
        Me.chkphilhealth.Text = "PHILHEALTH"
        Me.chkphilhealth.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(41, 141)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(492, 36)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "BROWSE FOR IMAGE"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txttotalrate
        '
        Me.txttotalrate.Enabled = False
        Me.txttotalrate.Location = New System.Drawing.Point(309, 439)
        Me.txttotalrate.Name = "txttotalrate"
        Me.txttotalrate.Size = New System.Drawing.Size(238, 30)
        Me.txttotalrate.TabIndex = 11
        Me.txttotalrate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chklaw)
        Me.GroupBox2.Controls.Add(Me.chkdoctorate)
        Me.GroupBox2.Controls.Add(Me.chkmasters)
        Me.GroupBox2.Location = New System.Drawing.Point(272, 309)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(292, 100)
        Me.GroupBox2.TabIndex = 9
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "ADDITIONAL RATE"
        '
        'chklaw
        '
        Me.chklaw.AutoSize = True
        Me.chklaw.Location = New System.Drawing.Point(19, 68)
        Me.chklaw.Name = "chklaw"
        Me.chklaw.Size = New System.Drawing.Size(191, 29)
        Me.chklaw.TabIndex = 2
        Me.chklaw.Text = "LAW GRADUATE"
        Me.chklaw.UseVisualStyleBackColor = True
        '
        'chkdoctorate
        '
        Me.chkdoctorate.AutoSize = True
        Me.chkdoctorate.Location = New System.Drawing.Point(19, 44)
        Me.chkdoctorate.Name = "chkdoctorate"
        Me.chkdoctorate.Size = New System.Drawing.Size(273, 29)
        Me.chkdoctorate.TabIndex = 1
        Me.chkdoctorate.Text = "DOCTORATE GRADUATE"
        Me.chkdoctorate.UseVisualStyleBackColor = True
        '
        'chkmasters
        '
        Me.chkmasters.AutoSize = True
        Me.chkmasters.Location = New System.Drawing.Point(19, 20)
        Me.chkmasters.Name = "chkmasters"
        Me.chkmasters.Size = New System.Drawing.Size(244, 29)
        Me.chkmasters.TabIndex = 0
        Me.chkmasters.Text = "MASTERS GRADUATE"
        Me.chkmasters.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(36, 442)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(243, 25)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "TOTAL RATE PER HOUR"
        '
        'txttardiness
        '
        Me.txttardiness.Enabled = False
        Me.txttardiness.Location = New System.Drawing.Point(288, 99)
        Me.txttardiness.Name = "txttardiness"
        Me.txttardiness.Size = New System.Drawing.Size(237, 30)
        Me.txttardiness.TabIndex = 16
        '
        'txthrequired
        '
        Me.txthrequired.Location = New System.Drawing.Point(288, 64)
        Me.txthrequired.Name = "txthrequired"
        Me.txthrequired.Size = New System.Drawing.Size(237, 30)
        Me.txthrequired.TabIndex = 15
        '
        'txthpermonth
        '
        Me.txthpermonth.Enabled = False
        Me.txthpermonth.Location = New System.Drawing.Point(288, 28)
        Me.txthpermonth.Name = "txthpermonth"
        Me.txthpermonth.Size = New System.Drawing.Size(237, 30)
        Me.txthpermonth.TabIndex = 14
        Me.txthpermonth.Text = "100 HOURS PER MONTH"
        Me.txthpermonth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 99)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(198, 25)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "TOTAL TARDINESS"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 62)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(276, 25)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "NO. OF HOUR(S) REQUIRED"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 28)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(276, 25)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "NO. OF HOUR(S) REQUIRED"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(41, 674)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(492, 34)
        Me.Button3.TabIndex = 14
        Me.Button3.Text = "EXIT SYSTEM"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(41, 635)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(494, 33)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "PROCEED TO NEXT PAGE"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txttardiness)
        Me.GroupBox3.Controls.Add(Me.txthrequired)
        Me.GroupBox3.Controls.Add(Me.txthpermonth)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Location = New System.Drawing.Point(22, 486)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(531, 143)
        Me.GroupBox3.TabIndex = 12
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "ATTENDANCE EVERY QUARTER"
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.tpRates)
        Me.TabControl2.Controls.Add(Me.tpPayroll)
        Me.TabControl2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.TabControl2.Location = New System.Drawing.Point(-3, 2)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(578, 763)
        Me.TabControl2.TabIndex = 2
        '
        'tpRates
        '
        Me.tpRates.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tpRates.Controls.Add(Me.Button3)
        Me.tpRates.Controls.Add(Me.Button2)
        Me.tpRates.Controls.Add(Me.GroupBox3)
        Me.tpRates.Controls.Add(Me.txttotalrate)
        Me.tpRates.Controls.Add(Me.Label4)
        Me.tpRates.Controls.Add(Me.GroupBox2)
        Me.tpRates.Controls.Add(Me.GroupBox1)
        Me.tpRates.Controls.Add(Me.txtmname)
        Me.tpRates.Controls.Add(Me.txtfname)
        Me.tpRates.Controls.Add(Me.txtlname)
        Me.tpRates.Controls.Add(Me.Label3)
        Me.tpRates.Controls.Add(Me.Label2)
        Me.tpRates.Controls.Add(Me.Label1)
        Me.tpRates.Controls.Add(Me.Button1)
        Me.tpRates.Controls.Add(Me.PictureBox1)
        Me.tpRates.Location = New System.Drawing.Point(4, 34)
        Me.tpRates.Name = "tpRates"
        Me.tpRates.Padding = New System.Windows.Forms.Padding(3)
        Me.tpRates.Size = New System.Drawing.Size(570, 725)
        Me.tpRates.TabIndex = 0
        Me.tpRates.Text = "Rates"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbjoborder)
        Me.GroupBox1.Controls.Add(Me.rbcontractual)
        Me.GroupBox1.Location = New System.Drawing.Point(11, 309)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(249, 100)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "RATE PER HOUR"
        '
        'rbjoborder
        '
        Me.rbjoborder.AutoSize = True
        Me.rbjoborder.Location = New System.Drawing.Point(16, 62)
        Me.rbjoborder.Name = "rbjoborder"
        Me.rbjoborder.Size = New System.Drawing.Size(144, 29)
        Me.rbjoborder.TabIndex = 9
        Me.rbjoborder.TabStop = True
        Me.rbjoborder.Text = "JOB ORDER"
        Me.rbjoborder.UseVisualStyleBackColor = True
        '
        'rbcontractual
        '
        Me.rbcontractual.AutoSize = True
        Me.rbcontractual.Location = New System.Drawing.Point(16, 27)
        Me.rbcontractual.Name = "rbcontractual"
        Me.rbcontractual.Size = New System.Drawing.Size(182, 29)
        Me.rbcontractual.TabIndex = 1
        Me.rbcontractual.TabStop = True
        Me.rbcontractual.Text = "CONTRACTUAL"
        Me.rbcontractual.UseVisualStyleBackColor = True
        '
        'txtmname
        '
        Me.txtmname.Location = New System.Drawing.Point(263, 221)
        Me.txtmname.Name = "txtmname"
        Me.txtmname.Size = New System.Drawing.Size(284, 30)
        Me.txtmname.TabIndex = 7
        '
        'txtfname
        '
        Me.txtfname.Location = New System.Drawing.Point(263, 185)
        Me.txtfname.Name = "txtfname"
        Me.txtfname.Size = New System.Drawing.Size(284, 30)
        Me.txtfname.TabIndex = 6
        '
        'txtlname
        '
        Me.txtlname.Location = New System.Drawing.Point(263, 258)
        Me.txtlname.Name = "txtlname"
        Me.txtlname.Size = New System.Drawing.Size(284, 30)
        Me.txtlname.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(71, 223)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(149, 25)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "MIDDLE NAME"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(72, 188)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(132, 25)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "FIRST NAME"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(571, 756)
        Me.Controls.Add(Me.TabControl2)
        Me.Name = "Form5"
        Me.Text = "Form5"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpPayroll.ResumeLayout(False)
        Me.tpPayroll.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.tpRates.ResumeLayout(False)
        Me.tpRates.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents tpPayroll As TabPage
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents txtdeductions As TextBox
    Friend WithEvents txtnet As TextBox
    Friend WithEvents txtgross As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtptax As TextBox
    Friend WithEvents txtdeduc As TextBox
    Friend WithEvents txtbenefits As TextBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents chkaitax As CheckBox
    Friend WithEvents chkawtax As CheckBox
    Friend WithEvents chkptax As CheckBox
    Friend WithEvents chkitax As CheckBox
    Friend WithEvents chkwtax As CheckBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents txtcoop As TextBox
    Friend WithEvents txtgsis As TextBox
    Friend WithEvents txtpagibig As TextBox
    Friend WithEvents txtsss As TextBox
    Friend WithEvents txtphilhealth As TextBox
    Friend WithEvents chkcoop As CheckBox
    Friend WithEvents chkgsis As CheckBox
    Friend WithEvents chkpagibig As CheckBox
    Friend WithEvents chksss As CheckBox
    Friend WithEvents chkphilhealth As CheckBox
    Friend WithEvents Button1 As Button
    Friend WithEvents txttotalrate As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents chklaw As CheckBox
    Friend WithEvents chkdoctorate As CheckBox
    Friend WithEvents chkmasters As CheckBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txttardiness As TextBox
    Friend WithEvents txthrequired As TextBox
    Friend WithEvents txthpermonth As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents tpRates As TabPage
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rbjoborder As RadioButton
    Friend WithEvents rbcontractual As RadioButton
    Friend WithEvents txtmname As TextBox
    Friend WithEvents txtfname As TextBox
    Friend WithEvents txtlname As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
End Class
