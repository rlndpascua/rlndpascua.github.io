﻿Public Class Form12
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) 
        TextBox2.Text = Val(TextBox1.Text) * 67.83
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) 
        TextBox2.Text = Val(TextBox1.Text) * 12.49
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) 
        TextBox2.Text = Val(TextBox1.Text) * 8.56
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) 
        TextBox2.Text = Val(TextBox1.Text) * 51.25
    End Sub

    Private Sub RadioButton5_CheckedChanged(sender As Object, e As EventArgs) 
        TextBox2.Text = Val(TextBox1.Text) * 2.55
    End Sub
End Class