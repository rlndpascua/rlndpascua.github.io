﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtchange = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtRec = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtDis = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtSea = New System.Windows.Forms.TextBox()
        Me.txtDes = New System.Windows.Forms.TextBox()
        Me.txtMer = New System.Windows.Forms.TextBox()
        Me.txtRice = New System.Windows.Forms.TextBox()
        Me.txtBeef = New System.Windows.Forms.TextBox()
        Me.txtPork = New System.Windows.Forms.TextBox()
        Me.txtChi = New System.Windows.Forms.TextBox()
        Me.txtVeg = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.GroupBox9.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtchange
        '
        Me.txtchange.BackColor = System.Drawing.Color.White
        Me.txtchange.Enabled = False
        Me.txtchange.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtchange.ForeColor = System.Drawing.Color.Black
        Me.txtchange.Location = New System.Drawing.Point(250, 540)
        Me.txtchange.Margin = New System.Windows.Forms.Padding(2)
        Me.txtchange.Name = "txtchange"
        Me.txtchange.Size = New System.Drawing.Size(235, 30)
        Me.txtchange.TabIndex = 35
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(26, 540)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(97, 25)
        Me.Label13.TabIndex = 34
        Me.Label13.Text = "CHANGE"
        '
        'txtRec
        '
        Me.txtRec.BackColor = System.Drawing.Color.White
        Me.txtRec.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtRec.ForeColor = System.Drawing.Color.Black
        Me.txtRec.Location = New System.Drawing.Point(250, 494)
        Me.txtRec.Margin = New System.Windows.Forms.Padding(2)
        Me.txtRec.Name = "txtRec"
        Me.txtRec.Size = New System.Drawing.Size(235, 30)
        Me.txtRec.TabIndex = 31
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(26, 497)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(191, 25)
        Me.Label3.TabIndex = 30
        Me.Label3.Text = "AMOUNT RECEIVE"
        '
        'txtDis
        '
        Me.txtDis.BackColor = System.Drawing.Color.White
        Me.txtDis.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtDis.ForeColor = System.Drawing.Color.Black
        Me.txtDis.Location = New System.Drawing.Point(250, 445)
        Me.txtDis.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDis.Name = "txtDis"
        Me.txtDis.Size = New System.Drawing.Size(235, 30)
        Me.txtDis.TabIndex = 29
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(35, 450)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(117, 25)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "DISCOUNT"
        '
        'txtAmount
        '
        Me.txtAmount.BackColor = System.Drawing.Color.White
        Me.txtAmount.Enabled = False
        Me.txtAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtAmount.ForeColor = System.Drawing.Color.Black
        Me.txtAmount.Location = New System.Drawing.Point(250, 399)
        Me.txtAmount.Margin = New System.Windows.Forms.Padding(2)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(235, 30)
        Me.txtAmount.TabIndex = 27
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(35, 404)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(146, 25)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "AMOUNT DUE"
        '
        'txtSea
        '
        Me.txtSea.BackColor = System.Drawing.Color.White
        Me.txtSea.Enabled = False
        Me.txtSea.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtSea.ForeColor = System.Drawing.Color.Black
        Me.txtSea.Location = New System.Drawing.Point(250, 353)
        Me.txtSea.Margin = New System.Windows.Forms.Padding(2)
        Me.txtSea.Name = "txtSea"
        Me.txtSea.Size = New System.Drawing.Size(235, 30)
        Me.txtSea.TabIndex = 25
        '
        'txtDes
        '
        Me.txtDes.BackColor = System.Drawing.Color.White
        Me.txtDes.Enabled = False
        Me.txtDes.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtDes.ForeColor = System.Drawing.Color.Black
        Me.txtDes.Location = New System.Drawing.Point(250, 307)
        Me.txtDes.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDes.Name = "txtDes"
        Me.txtDes.Size = New System.Drawing.Size(235, 30)
        Me.txtDes.TabIndex = 24
        '
        'txtMer
        '
        Me.txtMer.BackColor = System.Drawing.Color.White
        Me.txtMer.Enabled = False
        Me.txtMer.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtMer.ForeColor = System.Drawing.Color.Black
        Me.txtMer.Location = New System.Drawing.Point(250, 261)
        Me.txtMer.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMer.Name = "txtMer"
        Me.txtMer.Size = New System.Drawing.Size(235, 30)
        Me.txtMer.TabIndex = 23
        '
        'txtRice
        '
        Me.txtRice.BackColor = System.Drawing.Color.White
        Me.txtRice.Enabled = False
        Me.txtRice.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtRice.ForeColor = System.Drawing.Color.Black
        Me.txtRice.Location = New System.Drawing.Point(250, 213)
        Me.txtRice.Margin = New System.Windows.Forms.Padding(2)
        Me.txtRice.Name = "txtRice"
        Me.txtRice.Size = New System.Drawing.Size(235, 30)
        Me.txtRice.TabIndex = 22
        '
        'txtBeef
        '
        Me.txtBeef.BackColor = System.Drawing.Color.White
        Me.txtBeef.Enabled = False
        Me.txtBeef.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtBeef.ForeColor = System.Drawing.Color.Black
        Me.txtBeef.Location = New System.Drawing.Point(250, 166)
        Me.txtBeef.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBeef.Name = "txtBeef"
        Me.txtBeef.Size = New System.Drawing.Size(235, 30)
        Me.txtBeef.TabIndex = 21
        '
        'txtPork
        '
        Me.txtPork.BackColor = System.Drawing.Color.White
        Me.txtPork.Enabled = False
        Me.txtPork.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtPork.ForeColor = System.Drawing.Color.Black
        Me.txtPork.Location = New System.Drawing.Point(250, 116)
        Me.txtPork.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPork.Name = "txtPork"
        Me.txtPork.Size = New System.Drawing.Size(235, 30)
        Me.txtPork.TabIndex = 20
        '
        'txtChi
        '
        Me.txtChi.BackColor = System.Drawing.Color.White
        Me.txtChi.Enabled = False
        Me.txtChi.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtChi.ForeColor = System.Drawing.Color.Black
        Me.txtChi.Location = New System.Drawing.Point(250, 70)
        Me.txtChi.Margin = New System.Windows.Forms.Padding(2)
        Me.txtChi.Name = "txtChi"
        Me.txtChi.Size = New System.Drawing.Size(235, 30)
        Me.txtChi.TabIndex = 19
        '
        'txtVeg
        '
        Me.txtVeg.BackColor = System.Drawing.Color.White
        Me.txtVeg.Enabled = False
        Me.txtVeg.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtVeg.ForeColor = System.Drawing.Color.Black
        Me.txtVeg.Location = New System.Drawing.Point(250, 27)
        Me.txtVeg.Margin = New System.Windows.Forms.Padding(2)
        Me.txtVeg.Name = "txtVeg"
        Me.txtVeg.Size = New System.Drawing.Size(235, 30)
        Me.txtVeg.TabIndex = 18
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(35, 358)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(130, 25)
        Me.Label11.TabIndex = 17
        Me.Label11.Text = "SEA FOODS"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Control
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Button1.ForeColor = System.Drawing.Color.Black
        Me.Button1.Location = New System.Drawing.Point(41, 621)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(524, 69)
        Me.Button1.TabIndex = 26
        Me.Button1.Text = "OK"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(35, 312)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(125, 25)
        Me.Label10.TabIndex = 16
        Me.Label10.Text = "DESSERTS "
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(35, 266)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(115, 25)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "MERIENDA"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(35, 216)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(58, 25)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "RICE"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(30, 169)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(63, 25)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "BEEF"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(35, 119)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(68, 25)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "PORK"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(21, 75)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 25)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "CHICKEN"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(21, 32)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(131, 25)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "VEGETABLE"
        '
        'GroupBox9
        '
        Me.GroupBox9.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox9.Controls.Add(Me.txtchange)
        Me.GroupBox9.Controls.Add(Me.Label13)
        Me.GroupBox9.Controls.Add(Me.txtChi)
        Me.GroupBox9.Controls.Add(Me.txtRec)
        Me.GroupBox9.Controls.Add(Me.Label3)
        Me.GroupBox9.Controls.Add(Me.txtDis)
        Me.GroupBox9.Controls.Add(Me.Label2)
        Me.GroupBox9.Controls.Add(Me.txtAmount)
        Me.GroupBox9.Controls.Add(Me.Label1)
        Me.GroupBox9.Controls.Add(Me.txtSea)
        Me.GroupBox9.Controls.Add(Me.txtDes)
        Me.GroupBox9.Controls.Add(Me.txtMer)
        Me.GroupBox9.Controls.Add(Me.txtRice)
        Me.GroupBox9.Controls.Add(Me.txtBeef)
        Me.GroupBox9.Controls.Add(Me.txtPork)
        Me.GroupBox9.Controls.Add(Me.txtVeg)
        Me.GroupBox9.Controls.Add(Me.Label11)
        Me.GroupBox9.Controls.Add(Me.Label10)
        Me.GroupBox9.Controls.Add(Me.Label9)
        Me.GroupBox9.Controls.Add(Me.Label8)
        Me.GroupBox9.Controls.Add(Me.Label7)
        Me.GroupBox9.Controls.Add(Me.Label6)
        Me.GroupBox9.Controls.Add(Me.Label5)
        Me.GroupBox9.Controls.Add(Me.Label4)
        Me.GroupBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.GroupBox9.ForeColor = System.Drawing.Color.Black
        Me.GroupBox9.Location = New System.Drawing.Point(41, 29)
        Me.GroupBox9.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox9.Size = New System.Drawing.Size(524, 578)
        Me.GroupBox9.TabIndex = 25
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "PRICE"
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(604, 701)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox9)
        Me.Name = "Form4"
        Me.Text = "Form4"
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents txtchange As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtRec As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtDis As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtAmount As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtSea As TextBox
    Friend WithEvents txtDes As TextBox
    Friend WithEvents txtMer As TextBox
    Friend WithEvents txtRice As TextBox
    Friend WithEvents txtBeef As TextBox
    Friend WithEvents txtPork As TextBox
    Friend WithEvents txtChi As TextBox
    Friend WithEvents txtVeg As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents GroupBox9 As GroupBox
End Class
