﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rbHalo = New System.Windows.Forms.RadioButton()
        Me.rbSeafood = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkChopsuey = New System.Windows.Forms.CheckBox()
        Me.chkPinakbet = New System.Windows.Forms.CheckBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Nud1 = New System.Windows.Forms.NumericUpDown()
        Me.rbAdobo = New System.Windows.Forms.RadioButton()
        Me.rbDanggit = New System.Windows.Forms.RadioButton()
        Me.rbRegular = New System.Windows.Forms.RadioButton()
        Me.chkLetchon = New System.Windows.Forms.CheckBox()
        Me.chkBaka = New System.Windows.Forms.CheckBox()
        Me.txtSea = New System.Windows.Forms.TextBox()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.txtDes = New System.Windows.Forms.TextBox()
        Me.txtMer = New System.Windows.Forms.TextBox()
        Me.txtRice = New System.Windows.Forms.TextBox()
        Me.txtBeef = New System.Windows.Forms.TextBox()
        Me.txtPork = New System.Windows.Forms.TextBox()
        Me.txtChi = New System.Windows.Forms.TextBox()
        Me.txtVeg = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.rbFrozen = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.chkBeef = New System.Windows.Forms.CheckBox()
        Me.chkBicol = New System.Windows.Forms.CheckBox()
        Me.chkChicken = New System.Windows.Forms.CheckBox()
        Me.chkSpring = New System.Windows.Forms.CheckBox()
        Me.Nud2 = New System.Windows.Forms.NumericUpDown()
        Me.rbGiant = New System.Windows.Forms.RadioButton()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.rbPancit = New System.Windows.Forms.RadioButton()
        Me.rbArroz = New System.Windows.Forms.RadioButton()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.rbSinigang = New System.Windows.Forms.RadioButton()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.rbBoneless = New System.Windows.Forms.RadioButton()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Nud3 = New System.Windows.Forms.NumericUpDown()
        Me.Nud4 = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.rbBangus = New System.Windows.Forms.RadioButton()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.Nud1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.Nud2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        CType(Me.Nud3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Nud4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'rbHalo
        '
        Me.rbHalo.AutoSize = True
        Me.rbHalo.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbHalo.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.rbHalo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbHalo.Location = New System.Drawing.Point(37, 27)
        Me.rbHalo.Margin = New System.Windows.Forms.Padding(2)
        Me.rbHalo.Name = "rbHalo"
        Me.rbHalo.Size = New System.Drawing.Size(164, 29)
        Me.rbHalo.TabIndex = 6
        Me.rbHalo.TabStop = True
        Me.rbHalo.Text = "Halo Halo(P45)"
        Me.rbHalo.UseVisualStyleBackColor = False
        '
        'rbSeafood
        '
        Me.rbSeafood.AutoSize = True
        Me.rbSeafood.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbSeafood.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.rbSeafood.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbSeafood.Location = New System.Drawing.Point(51, 84)
        Me.rbSeafood.Margin = New System.Windows.Forms.Padding(2)
        Me.rbSeafood.Name = "rbSeafood"
        Me.rbSeafood.Size = New System.Drawing.Size(200, 29)
        Me.rbSeafood.TabIndex = 5
        Me.rbSeafood.TabStop = True
        Me.rbSeafood.Text = "Seafood Lomi(P80)"
        Me.rbSeafood.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.chkChopsuey)
        Me.GroupBox1.Controls.Add(Me.chkPinakbet)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox1.Location = New System.Drawing.Point(40, 33)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(332, 98)
        Me.GroupBox1.TabIndex = 28
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "VEGETABLE"
        '
        'chkChopsuey
        '
        Me.chkChopsuey.AutoSize = True
        Me.chkChopsuey.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chkChopsuey.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.chkChopsuey.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.chkChopsuey.Location = New System.Drawing.Point(13, 56)
        Me.chkChopsuey.Margin = New System.Windows.Forms.Padding(2)
        Me.chkChopsuey.Name = "chkChopsuey"
        Me.chkChopsuey.Size = New System.Drawing.Size(170, 29)
        Me.chkChopsuey.TabIndex = 1
        Me.chkChopsuey.Text = "Chopsuey(P50)"
        Me.chkChopsuey.UseVisualStyleBackColor = False
        '
        'chkPinakbet
        '
        Me.chkPinakbet.AutoSize = True
        Me.chkPinakbet.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chkPinakbet.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.chkPinakbet.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.chkPinakbet.Location = New System.Drawing.Point(13, 27)
        Me.chkPinakbet.Margin = New System.Windows.Forms.Padding(2)
        Me.chkPinakbet.Name = "chkPinakbet"
        Me.chkPinakbet.Size = New System.Drawing.Size(143, 29)
        Me.chkPinakbet.TabIndex = 1
        Me.chkPinakbet.Text = "Pinakbet(45)"
        Me.chkPinakbet.UseVisualStyleBackColor = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label15.Location = New System.Drawing.Point(46, 122)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(85, 25)
        Me.Label15.TabIndex = 15
        Me.Label15.Text = "Quantity"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label12.Location = New System.Drawing.Point(32, 117)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(85, 25)
        Me.Label12.TabIndex = 14
        Me.Label12.Text = "Quantity"
        '
        'Nud1
        '
        Me.Nud1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Nud1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Nud1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Nud1.Location = New System.Drawing.Point(144, 115)
        Me.Nud1.Margin = New System.Windows.Forms.Padding(2)
        Me.Nud1.Name = "Nud1"
        Me.Nud1.Size = New System.Drawing.Size(108, 30)
        Me.Nud1.TabIndex = 5
        '
        'rbAdobo
        '
        Me.rbAdobo.AutoSize = True
        Me.rbAdobo.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbAdobo.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.rbAdobo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbAdobo.Location = New System.Drawing.Point(37, 88)
        Me.rbAdobo.Margin = New System.Windows.Forms.Padding(2)
        Me.rbAdobo.Name = "rbAdobo"
        Me.rbAdobo.Size = New System.Drawing.Size(191, 29)
        Me.rbAdobo.TabIndex = 6
        Me.rbAdobo.TabStop = True
        Me.rbAdobo.Text = "Adobo Rice(P100)"
        Me.rbAdobo.UseVisualStyleBackColor = False
        '
        'rbDanggit
        '
        Me.rbDanggit.AutoSize = True
        Me.rbDanggit.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbDanggit.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.rbDanggit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbDanggit.Location = New System.Drawing.Point(37, 55)
        Me.rbDanggit.Margin = New System.Windows.Forms.Padding(2)
        Me.rbDanggit.Name = "rbDanggit"
        Me.rbDanggit.Size = New System.Drawing.Size(189, 29)
        Me.rbDanggit.TabIndex = 6
        Me.rbDanggit.TabStop = True
        Me.rbDanggit.Text = "Danggit Rice(P70)"
        Me.rbDanggit.UseVisualStyleBackColor = False
        '
        'rbRegular
        '
        Me.rbRegular.AutoSize = True
        Me.rbRegular.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbRegular.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.rbRegular.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbRegular.Location = New System.Drawing.Point(37, 27)
        Me.rbRegular.Margin = New System.Windows.Forms.Padding(2)
        Me.rbRegular.Name = "rbRegular"
        Me.rbRegular.Size = New System.Drawing.Size(146, 29)
        Me.rbRegular.TabIndex = 5
        Me.rbRegular.TabStop = True
        Me.rbRegular.Text = "Regular(P50)"
        Me.rbRegular.UseVisualStyleBackColor = False
        '
        'chkLetchon
        '
        Me.chkLetchon.AutoSize = True
        Me.chkLetchon.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chkLetchon.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.chkLetchon.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.chkLetchon.Location = New System.Drawing.Point(32, 60)
        Me.chkLetchon.Margin = New System.Windows.Forms.Padding(2)
        Me.chkLetchon.Name = "chkLetchon"
        Me.chkLetchon.Size = New System.Drawing.Size(219, 29)
        Me.chkLetchon.TabIndex = 1
        Me.chkLetchon.Text = "Lechon Kawali(P200)"
        Me.chkLetchon.UseVisualStyleBackColor = False
        '
        'chkBaka
        '
        Me.chkBaka.AutoSize = True
        Me.chkBaka.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chkBaka.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.chkBaka.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.chkBaka.Location = New System.Drawing.Point(41, 27)
        Me.chkBaka.Margin = New System.Windows.Forms.Padding(2)
        Me.chkBaka.Name = "chkBaka"
        Me.chkBaka.Size = New System.Drawing.Size(218, 29)
        Me.chkBaka.TabIndex = 1
        Me.chkBaka.Text = "Nilagang Baka(P100)"
        Me.chkBaka.UseVisualStyleBackColor = False
        '
        'txtSea
        '
        Me.txtSea.BackColor = System.Drawing.SystemColors.Control
        Me.txtSea.Enabled = False
        Me.txtSea.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtSea.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtSea.Location = New System.Drawing.Point(238, 462)
        Me.txtSea.Margin = New System.Windows.Forms.Padding(2)
        Me.txtSea.Name = "txtSea"
        Me.txtSea.Size = New System.Drawing.Size(157, 30)
        Me.txtSea.TabIndex = 25
        '
        'GroupBox9
        '
        Me.GroupBox9.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox9.Controls.Add(Me.txtSea)
        Me.GroupBox9.Controls.Add(Me.txtDes)
        Me.GroupBox9.Controls.Add(Me.txtMer)
        Me.GroupBox9.Controls.Add(Me.txtRice)
        Me.GroupBox9.Controls.Add(Me.txtBeef)
        Me.GroupBox9.Controls.Add(Me.txtPork)
        Me.GroupBox9.Controls.Add(Me.txtChi)
        Me.GroupBox9.Controls.Add(Me.txtVeg)
        Me.GroupBox9.Controls.Add(Me.Label11)
        Me.GroupBox9.Controls.Add(Me.Label10)
        Me.GroupBox9.Controls.Add(Me.Label9)
        Me.GroupBox9.Controls.Add(Me.Label8)
        Me.GroupBox9.Controls.Add(Me.Label7)
        Me.GroupBox9.Controls.Add(Me.Label6)
        Me.GroupBox9.Controls.Add(Me.Label5)
        Me.GroupBox9.Controls.Add(Me.Label4)
        Me.GroupBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.GroupBox9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox9.Location = New System.Drawing.Point(755, 33)
        Me.GroupBox9.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox9.Size = New System.Drawing.Size(413, 557)
        Me.GroupBox9.TabIndex = 36
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "ORDERS"
        '
        'txtDes
        '
        Me.txtDes.BackColor = System.Drawing.SystemColors.Control
        Me.txtDes.Enabled = False
        Me.txtDes.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtDes.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtDes.Location = New System.Drawing.Point(238, 402)
        Me.txtDes.Margin = New System.Windows.Forms.Padding(2)
        Me.txtDes.Name = "txtDes"
        Me.txtDes.Size = New System.Drawing.Size(157, 30)
        Me.txtDes.TabIndex = 24
        '
        'txtMer
        '
        Me.txtMer.BackColor = System.Drawing.SystemColors.Control
        Me.txtMer.Enabled = False
        Me.txtMer.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtMer.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtMer.Location = New System.Drawing.Point(238, 347)
        Me.txtMer.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMer.Name = "txtMer"
        Me.txtMer.Size = New System.Drawing.Size(157, 30)
        Me.txtMer.TabIndex = 23
        '
        'txtRice
        '
        Me.txtRice.BackColor = System.Drawing.SystemColors.Control
        Me.txtRice.Enabled = False
        Me.txtRice.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtRice.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtRice.Location = New System.Drawing.Point(238, 287)
        Me.txtRice.Margin = New System.Windows.Forms.Padding(2)
        Me.txtRice.Name = "txtRice"
        Me.txtRice.Size = New System.Drawing.Size(157, 30)
        Me.txtRice.TabIndex = 22
        '
        'txtBeef
        '
        Me.txtBeef.BackColor = System.Drawing.SystemColors.Control
        Me.txtBeef.Enabled = False
        Me.txtBeef.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtBeef.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtBeef.Location = New System.Drawing.Point(238, 231)
        Me.txtBeef.Margin = New System.Windows.Forms.Padding(2)
        Me.txtBeef.Name = "txtBeef"
        Me.txtBeef.Size = New System.Drawing.Size(157, 30)
        Me.txtBeef.TabIndex = 21
        '
        'txtPork
        '
        Me.txtPork.BackColor = System.Drawing.SystemColors.Control
        Me.txtPork.Enabled = False
        Me.txtPork.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtPork.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtPork.Location = New System.Drawing.Point(238, 180)
        Me.txtPork.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPork.Name = "txtPork"
        Me.txtPork.Size = New System.Drawing.Size(157, 30)
        Me.txtPork.TabIndex = 20
        '
        'txtChi
        '
        Me.txtChi.BackColor = System.Drawing.SystemColors.Control
        Me.txtChi.Enabled = False
        Me.txtChi.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtChi.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtChi.Location = New System.Drawing.Point(238, 119)
        Me.txtChi.Margin = New System.Windows.Forms.Padding(2)
        Me.txtChi.Name = "txtChi"
        Me.txtChi.Size = New System.Drawing.Size(157, 30)
        Me.txtChi.TabIndex = 19
        '
        'txtVeg
        '
        Me.txtVeg.BackColor = System.Drawing.SystemColors.Control
        Me.txtVeg.Enabled = False
        Me.txtVeg.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtVeg.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.txtVeg.Location = New System.Drawing.Point(236, 57)
        Me.txtVeg.Margin = New System.Windows.Forms.Padding(2)
        Me.txtVeg.Name = "txtVeg"
        Me.txtVeg.Size = New System.Drawing.Size(159, 30)
        Me.txtVeg.TabIndex = 18
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label11.Location = New System.Drawing.Point(61, 467)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(130, 25)
        Me.Label11.TabIndex = 17
        Me.Label11.Text = "SEA FOODS"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label10.Location = New System.Drawing.Point(66, 407)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(125, 25)
        Me.Label10.TabIndex = 16
        Me.Label10.Text = "DESSERTS "
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label9.Location = New System.Drawing.Point(66, 347)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(115, 25)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "MERIENDA"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label8.Location = New System.Drawing.Point(72, 292)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(58, 25)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "RICE"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label7.Location = New System.Drawing.Point(72, 236)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(63, 25)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "BEEF"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label6.Location = New System.Drawing.Point(72, 183)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(68, 25)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "PORK"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label5.Location = New System.Drawing.Point(72, 122)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 25)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "CHICKEN"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Location = New System.Drawing.Point(72, 59)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(131, 25)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "VEGETABLE"
        '
        'rbFrozen
        '
        Me.rbFrozen.AutoSize = True
        Me.rbFrozen.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbFrozen.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.rbFrozen.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbFrozen.Location = New System.Drawing.Point(37, 86)
        Me.rbFrozen.Margin = New System.Windows.Forms.Padding(2)
        Me.rbFrozen.Name = "rbFrozen"
        Me.rbFrozen.Size = New System.Drawing.Size(250, 29)
        Me.rbFrozen.TabIndex = 5
        Me.rbFrozen.TabStop = True
        Me.rbFrozen.Text = "Frozen Fruit Salad(P120)"
        Me.rbFrozen.UseVisualStyleBackColor = False
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox4.Controls.Add(Me.chkBaka)
        Me.GroupBox4.Controls.Add(Me.chkBeef)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.GroupBox4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox4.Location = New System.Drawing.Point(393, 146)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox4.Size = New System.Drawing.Size(333, 88)
        Me.GroupBox4.TabIndex = 31
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "BEEF"
        '
        'chkBeef
        '
        Me.chkBeef.AutoSize = True
        Me.chkBeef.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chkBeef.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.chkBeef.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.chkBeef.Location = New System.Drawing.Point(41, 51)
        Me.chkBeef.Margin = New System.Windows.Forms.Padding(2)
        Me.chkBeef.Name = "chkBeef"
        Me.chkBeef.Size = New System.Drawing.Size(221, 29)
        Me.chkBeef.TabIndex = 1
        Me.chkBeef.Text = "Beef Caldereta(P250)"
        Me.chkBeef.UseVisualStyleBackColor = False
        '
        'chkBicol
        '
        Me.chkBicol.AutoSize = True
        Me.chkBicol.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chkBicol.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.chkBicol.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.chkBicol.Location = New System.Drawing.Point(32, 27)
        Me.chkBicol.Margin = New System.Windows.Forms.Padding(2)
        Me.chkBicol.Name = "chkBicol"
        Me.chkBicol.Size = New System.Drawing.Size(209, 29)
        Me.chkBicol.TabIndex = 1
        Me.chkBicol.Text = "Bicol Express(P150)"
        Me.chkBicol.UseVisualStyleBackColor = False
        '
        'chkChicken
        '
        Me.chkChicken.AutoSize = True
        Me.chkChicken.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chkChicken.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.chkChicken.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.chkChicken.Location = New System.Drawing.Point(9, 27)
        Me.chkChicken.Margin = New System.Windows.Forms.Padding(2)
        Me.chkChicken.Name = "chkChicken"
        Me.chkChicken.Size = New System.Drawing.Size(211, 29)
        Me.chkChicken.TabIndex = 1
        Me.chkChicken.Text = "Chicken Sisig(P100)"
        Me.chkChicken.UseVisualStyleBackColor = False
        '
        'chkSpring
        '
        Me.chkSpring.AutoSize = True
        Me.chkSpring.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.chkSpring.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.chkSpring.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.chkSpring.Location = New System.Drawing.Point(9, 51)
        Me.chkSpring.Margin = New System.Windows.Forms.Padding(2)
        Me.chkSpring.Name = "chkSpring"
        Me.chkSpring.Size = New System.Drawing.Size(225, 29)
        Me.chkSpring.TabIndex = 1
        Me.chkSpring.Text = "Spring Chicken(P150)"
        Me.chkSpring.UseVisualStyleBackColor = False
        '
        'Nud2
        '
        Me.Nud2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Nud2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Nud2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Nud2.Location = New System.Drawing.Point(157, 115)
        Me.Nud2.Margin = New System.Windows.Forms.Padding(2)
        Me.Nud2.Name = "Nud2"
        Me.Nud2.Size = New System.Drawing.Size(91, 30)
        Me.Nud2.TabIndex = 5
        '
        'rbGiant
        '
        Me.rbGiant.AutoSize = True
        Me.rbGiant.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbGiant.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.rbGiant.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbGiant.Location = New System.Drawing.Point(37, 60)
        Me.rbGiant.Margin = New System.Windows.Forms.Padding(2)
        Me.rbGiant.Name = "rbGiant"
        Me.rbGiant.Size = New System.Drawing.Size(215, 29)
        Me.rbGiant.TabIndex = 6
        Me.rbGiant.TabStop = True
        Me.rbGiant.Text = "Giant Halo Halo(P90)"
        Me.rbGiant.UseVisualStyleBackColor = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label13.Location = New System.Drawing.Point(46, 115)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(85, 25)
        Me.Label13.TabIndex = 15
        Me.Label13.Text = "Quantity"
        '
        'rbPancit
        '
        Me.rbPancit.AutoSize = True
        Me.rbPancit.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbPancit.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.rbPancit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbPancit.Location = New System.Drawing.Point(51, 31)
        Me.rbPancit.Margin = New System.Windows.Forms.Padding(2)
        Me.rbPancit.Name = "rbPancit"
        Me.rbPancit.Size = New System.Drawing.Size(197, 29)
        Me.rbPancit.TabIndex = 6
        Me.rbPancit.TabStop = True
        Me.rbPancit.Text = "Pancit Luglug(P30)"
        Me.rbPancit.UseVisualStyleBackColor = False
        '
        'rbArroz
        '
        Me.rbArroz.AutoSize = True
        Me.rbArroz.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbArroz.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.rbArroz.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbArroz.Location = New System.Drawing.Point(51, 60)
        Me.rbArroz.Margin = New System.Windows.Forms.Padding(2)
        Me.rbArroz.Name = "rbArroz"
        Me.rbArroz.Size = New System.Drawing.Size(183, 29)
        Me.rbArroz.TabIndex = 6
        Me.rbArroz.TabStop = True
        Me.rbArroz.Text = "Arroz Caldo(P50)"
        Me.rbArroz.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Control
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button1.Location = New System.Drawing.Point(40, 598)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(686, 57)
        Me.Button1.TabIndex = 40
        Me.Button1.Text = "BILL OUT"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.Control
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button2.Location = New System.Drawing.Point(755, 598)
        Me.Button2.Margin = New System.Windows.Forms.Padding(2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(413, 57)
        Me.Button2.TabIndex = 41
        Me.Button2.Text = "RESET"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'rbSinigang
        '
        Me.rbSinigang.AutoSize = True
        Me.rbSinigang.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbSinigang.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.rbSinigang.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbSinigang.Location = New System.Drawing.Point(51, 60)
        Me.rbSinigang.Margin = New System.Windows.Forms.Padding(2)
        Me.rbSinigang.Name = "rbSinigang"
        Me.rbSinigang.Size = New System.Drawing.Size(237, 29)
        Me.rbSinigang.TabIndex = 6
        Me.rbSinigang.TabStop = True
        Me.rbSinigang.Text = "Sinigang na Hipon(150)"
        Me.rbSinigang.UseVisualStyleBackColor = False
        '
        'GroupBox6
        '
        Me.GroupBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox6.Controls.Add(Me.Label13)
        Me.GroupBox6.Controls.Add(Me.Nud2)
        Me.GroupBox6.Controls.Add(Me.rbPancit)
        Me.GroupBox6.Controls.Add(Me.rbArroz)
        Me.GroupBox6.Controls.Add(Me.rbSeafood)
        Me.GroupBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.GroupBox6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox6.Location = New System.Drawing.Point(393, 260)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox6.Size = New System.Drawing.Size(333, 153)
        Me.GroupBox6.TabIndex = 33
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "MERIENDA"
        '
        'rbBoneless
        '
        Me.rbBoneless.AutoSize = True
        Me.rbBoneless.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbBoneless.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.rbBoneless.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbBoneless.Location = New System.Drawing.Point(51, 27)
        Me.rbBoneless.Margin = New System.Windows.Forms.Padding(2)
        Me.rbBoneless.Name = "rbBoneless"
        Me.rbBoneless.Size = New System.Drawing.Size(243, 29)
        Me.rbBoneless.TabIndex = 6
        Me.rbBoneless.TabStop = True
        Me.rbBoneless.Text = "Boneless Bangus(P120)"
        Me.rbBoneless.UseVisualStyleBackColor = False
        '
        'GroupBox7
        '
        Me.GroupBox7.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox7.Controls.Add(Me.Label14)
        Me.GroupBox7.Controls.Add(Me.Nud3)
        Me.GroupBox7.Controls.Add(Me.rbHalo)
        Me.GroupBox7.Controls.Add(Me.rbGiant)
        Me.GroupBox7.Controls.Add(Me.rbFrozen)
        Me.GroupBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.GroupBox7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox7.Location = New System.Drawing.Point(40, 440)
        Me.GroupBox7.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox7.Size = New System.Drawing.Size(332, 154)
        Me.GroupBox7.TabIndex = 34
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "DESSERTS "
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Label14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label14.Location = New System.Drawing.Point(32, 117)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(85, 25)
        Me.Label14.TabIndex = 15
        Me.Label14.Text = "Quantity"
        '
        'Nud3
        '
        Me.Nud3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Nud3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Nud3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Nud3.Location = New System.Drawing.Point(144, 115)
        Me.Nud3.Margin = New System.Windows.Forms.Padding(2)
        Me.Nud3.Name = "Nud3"
        Me.Nud3.Size = New System.Drawing.Size(108, 30)
        Me.Nud3.TabIndex = 5
        '
        'Nud4
        '
        Me.Nud4.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Nud4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.Nud4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Nud4.Location = New System.Drawing.Point(157, 122)
        Me.Nud4.Margin = New System.Windows.Forms.Padding(2)
        Me.Nud4.Name = "Nud4"
        Me.Nud4.Size = New System.Drawing.Size(91, 30)
        Me.Nud4.TabIndex = 5
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox3.Controls.Add(Me.chkBicol)
        Me.GroupBox3.Controls.Add(Me.chkLetchon)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox3.Location = New System.Drawing.Point(393, 31)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Size = New System.Drawing.Size(333, 100)
        Me.GroupBox3.TabIndex = 30
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "PORK"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.chkChicken)
        Me.GroupBox2.Controls.Add(Me.chkSpring)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox2.Location = New System.Drawing.Point(40, 146)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(332, 95)
        Me.GroupBox2.TabIndex = 29
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "CHICKEN"
        '
        'GroupBox8
        '
        Me.GroupBox8.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox8.Controls.Add(Me.Label15)
        Me.GroupBox8.Controls.Add(Me.Nud4)
        Me.GroupBox8.Controls.Add(Me.rbBoneless)
        Me.GroupBox8.Controls.Add(Me.rbSinigang)
        Me.GroupBox8.Controls.Add(Me.rbBangus)
        Me.GroupBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.GroupBox8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox8.Location = New System.Drawing.Point(393, 440)
        Me.GroupBox8.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox8.Size = New System.Drawing.Size(333, 154)
        Me.GroupBox8.TabIndex = 35
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "SEA FOODS"
        '
        'rbBangus
        '
        Me.rbBangus.AutoSize = True
        Me.rbBangus.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.rbBangus.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.rbBangus.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.rbBangus.Location = New System.Drawing.Point(51, 93)
        Me.rbBangus.Margin = New System.Windows.Forms.Padding(2)
        Me.rbBangus.Name = "rbBangus"
        Me.rbBangus.Size = New System.Drawing.Size(258, 29)
        Me.rbBangus.TabIndex = 5
        Me.rbBangus.TabStop = True
        Me.rbBangus.Text = "Bangus Tofu Steak(P200)"
        Me.rbBangus.UseVisualStyleBackColor = False
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox5.Controls.Add(Me.Label12)
        Me.GroupBox5.Controls.Add(Me.Nud1)
        Me.GroupBox5.Controls.Add(Me.rbAdobo)
        Me.GroupBox5.Controls.Add(Me.rbDanggit)
        Me.GroupBox5.Controls.Add(Me.rbRegular)
        Me.GroupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.GroupBox5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.GroupBox5.Location = New System.Drawing.Point(40, 260)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox5.Size = New System.Drawing.Size(332, 155)
        Me.GroupBox5.TabIndex = 32
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "RICE"
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1205, 666)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox5)
        Me.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Name = "Form3"
        Me.Text = "Form3"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.Nud1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.Nud2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        CType(Me.Nud3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Nud4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents rbHalo As RadioButton
    Friend WithEvents rbSeafood As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents chkChopsuey As CheckBox
    Friend WithEvents chkPinakbet As CheckBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Nud1 As NumericUpDown
    Friend WithEvents rbAdobo As RadioButton
    Friend WithEvents rbDanggit As RadioButton
    Friend WithEvents rbRegular As RadioButton
    Friend WithEvents chkLetchon As CheckBox
    Friend WithEvents chkBaka As CheckBox
    Friend WithEvents txtSea As TextBox
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents txtDes As TextBox
    Friend WithEvents txtMer As TextBox
    Friend WithEvents txtRice As TextBox
    Friend WithEvents txtBeef As TextBox
    Friend WithEvents txtPork As TextBox
    Friend WithEvents txtChi As TextBox
    Friend WithEvents txtVeg As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents rbFrozen As RadioButton
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents chkBeef As CheckBox
    Friend WithEvents chkBicol As CheckBox
    Friend WithEvents chkChicken As CheckBox
    Friend WithEvents chkSpring As CheckBox
    Friend WithEvents Nud2 As NumericUpDown
    Friend WithEvents rbGiant As RadioButton
    Friend WithEvents Label13 As Label
    Friend WithEvents rbPancit As RadioButton
    Friend WithEvents rbArroz As RadioButton
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents rbSinigang As RadioButton
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents rbBoneless As RadioButton
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Nud3 As NumericUpDown
    Friend WithEvents Nud4 As NumericUpDown
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents rbBangus As RadioButton
    Friend WithEvents GroupBox5 As GroupBox
End Class
