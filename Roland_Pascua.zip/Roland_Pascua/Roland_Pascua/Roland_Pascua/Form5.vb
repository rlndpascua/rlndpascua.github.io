﻿Public Class Form5
    Private Sub tpPayroll_Click(sender As Object, e As EventArgs) Handles tpPayroll.Click

    End Sub

    Private Sub txtcoop_TextChanged(sender As Object, e As EventArgs) Handles txtcoop.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        OpenFileDialog1.ShowDialog()
        PictureBox1.ImageLocation = OpenFileDialog1.FileName

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TabControl2.SelectedIndex = TabControl2.SelectedIndex
    End Sub
End Class